package com.example.sample3mad.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log

class ReminderService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("ReminderService", "Service Started")
        Thread {
            try {
                Thread.sleep(5000)
                Log.d("ReminderService", "Reminder triggered after 5 seconds!")
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }.start()

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
