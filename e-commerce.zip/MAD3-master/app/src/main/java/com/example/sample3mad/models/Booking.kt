package com.example.sample3mad.models

data class Booking(
    val eventName: String,
    val bookingTime: Long = System.currentTimeMillis(),
    val isConfirmed: Boolean = false
)
