package com.example.sample3mad.models

import java.io.Serializable

data class Product(
    val id: Int,
    val name: String,
    val description: String,
    val price: Double,
    val imageResId: Int,
    var quantity: Int = 1
) : Serializable