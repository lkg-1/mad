package com.example.sample3mad.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample3mad.R
import com.example.sample3mad.adapters.ProductAdapter
import com.example.sample3mad.models.Product
import com.example.sample3mad.utils.CartManager
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * The main activity of the application that displays a list of products and handles navigation.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var rvProducts: RecyclerView
    private lateinit var bottomNavigation: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvProducts = findViewById(R.id.rvProducts)
        bottomNavigation = findViewById(R.id.bottomNavigation)

        setupRecyclerView()
        setupBottomNavigation()
    }

    /**
     * Sets up the RecyclerView with a list of mock products and an adapter.
     * Handles adding products to the cart when clicked.
     */
    private fun setupRecyclerView() {
        val products = listOf(
            Product(1, "Smartphone", "Latest high-end smartphone with OLED display", 999.99, android.R.drawable.ic_menu_call),
            Product(2, "Laptop", "Powerful laptop for gaming and productivity", 1499.99, android.R.drawable.ic_menu_view),
            Product(3, "Headphones", "Noise-cancelling wireless headphones", 199.99, android.R.drawable.ic_lock_silent_mode),
            Product(4, "Smartwatch", "Feature-rich smartwatch with fitness tracking", 249.99, android.R.drawable.ic_menu_recent_history),
            Product(5, "Tablet", "Portable tablet for entertainment and work", 599.99, android.R.drawable.ic_menu_gallery),
            Product(6, "Camera", "Professional DSLR camera for high-quality photos", 1299.99, android.R.drawable.ic_menu_camera)
        )

        val adapter = ProductAdapter(products) { product ->
            CartManager.addToCart(this, product)
            Toast.makeText(this, "${product.name} added to cart", Toast.LENGTH_SHORT).show()
        }

        rvProducts.layoutManager = LinearLayoutManager(this)
        rvProducts.adapter = adapter
    }

    /**
     * Configures the BottomNavigationView to handle navigation between Home, Cart, and Profile screens.
     */
    private fun setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_cart -> {
                    startActivity(Intent(this, CartActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }
}