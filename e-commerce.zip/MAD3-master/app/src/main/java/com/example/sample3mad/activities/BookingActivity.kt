package com.example.sample3mad.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.sample3mad.R
import com.example.sample3mad.services.ReminderService
import com.example.sample3mad.utils.NotificationHelper
import com.example.sample3mad.utils.SMSHelper

class BookingActivity : AppCompatActivity() {
    private var eventName: String? = null
    private val PERMISSION_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        eventName = intent.getStringExtra("event")
        val txtEvent = findViewById<TextView>(R.id.txtEvent)
        txtEvent.text = eventName ?: "No Event Selected"

        val btnConfirm = findViewById<Button>(R.id.btnConfirm)
        btnConfirm.setOnClickListener {
            if (checkPermissions()) {
                showConfirmDialog()
            } else {
                requestPermissions()
            }
        }
    }

    private fun checkPermissions(): Boolean {
        val smsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
        val notificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            PackageManager.PERMISSION_GRANTED
        }
        return smsPermission == PackageManager.PERMISSION_GRANTED && notificationPermission == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), PERMISSION_REQUEST_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                showConfirmDialog()
            } else {
                Toast.makeText(this, "Permissions required for booking features", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirm Booking")
            .setMessage("Do you want to confirm booking for $eventName?")
            .setPositiveButton("Yes") { _, _ ->
                // Send Notification
                NotificationHelper.sendNotification(this)
                
                // Send SMS (assuming a number for demo)
                SMSHelper.sendSMS(this, "1234567890", "Your booking for $eventName is confirmed!")

                // Start Reminder Service
                val intent = Intent(this, ReminderService::class.java)
                startService(intent)

                Toast.makeText(this, "Booking Successful!", Toast.LENGTH_LONG).show()
                finish()
            }
            .setNegativeButton("No", null)
            .show()
    }
}