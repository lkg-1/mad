package com.example.sample3mad.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.sample3mad.R
import com.example.sample3mad.models.Product

class CartAdapter(
    private val cartItems: MutableList<Product>,
    private val onRemove: (Product) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivCartProductImage: ImageView = view.findViewById(R.id.ivCartProductImage)
        val tvCartProductName: TextView = view.findViewById(R.id.tvCartProductName)
        val tvCartProductQuantity: TextView = view.findViewById(R.id.tvCartProductQuantity)
        val tvCartProductPrice: TextView = view.findViewById(R.id.tvCartProductPrice)
        val btnRemoveFromCart: Button = view.findViewById(R.id.btnRemoveFromCart)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val product = cartItems[position]
        holder.tvCartProductName.text = product.name
        holder.tvCartProductQuantity.text = "Quantity: ${product.quantity}"
        holder.tvCartProductPrice.text = "$${product.price * product.quantity}"
        holder.ivCartProductImage.setImageResource(product.imageResId)

        holder.btnRemoveFromCart.setOnClickListener {
            onRemove(product)
            cartItems.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, cartItems.size)
        }
    }

    override fun getItemCount(): Int = cartItems.size
}