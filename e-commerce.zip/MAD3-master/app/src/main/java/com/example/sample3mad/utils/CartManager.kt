package com.example.sample3mad.utils

import android.content.Context
import com.example.sample3mad.models.Product

object CartManager {
    private val cartItems = mutableListOf<Product>()

    fun addToCart(context: Context, product: Product) {
        val existingItem = cartItems.find { it.id == product.id }
        if (existingItem != null) {
            existingItem.quantity++
        } else {
            cartItems.add(product.copy(quantity = 1))
        }
        
        if (getCartCount() > 5) {
            NotificationHelper.showNotification(context, "Cart Alert", "You have added more than 5 items to your cart.")
        }
    }

    fun removeFromCart(product: Product) {
        cartItems.removeIf { it.id == product.id }
    }

    fun getCartItems(): List<Product> = cartItems

    fun getCartCount(): Int = cartItems.sumOf { it.quantity }

    fun getTotalPrice(): Double = cartItems.sumOf { it.price * it.quantity }

    fun clearCart() {
        cartItems.clear()
    }
}