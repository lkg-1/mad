package com.example.sample3mad.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample3mad.R
import com.example.sample3mad.adapters.CartAdapter
import com.example.sample3mad.utils.CartManager
import java.util.Locale

class CartActivity : AppCompatActivity() {
    private lateinit var rvCartItems: RecyclerView
    private lateinit var tvEmptyCart: TextView
    private lateinit var tvTotalPrice: TextView
    private lateinit var btnCheckout: Button
    private lateinit var cartAdapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        rvCartItems = findViewById(R.id.rvCartItems)
        tvEmptyCart = findViewById(R.id.tvEmptyCart)
        tvTotalPrice = findViewById(R.id.tvTotalPrice)
        btnCheckout = findViewById(R.id.btnCheckout)

        setupRecyclerView()
        updateEmptyState()

        btnCheckout.setOnClickListener {
            processCheckout()
        }
    }

    private fun setupRecyclerView() {
        val cartItems = CartManager.getCartItems().toMutableList()
        cartAdapter = CartAdapter(cartItems) { product ->
            CartManager.removeFromCart(product)
            updateEmptyState()
            updateTotalPrice()
        }
        rvCartItems.layoutManager = LinearLayoutManager(this)
        rvCartItems.adapter = cartAdapter
        updateTotalPrice()
    }

    private fun updateTotalPrice() {
        tvTotalPrice.text = String.format("$%.2f", CartManager.getTotalPrice())
    }

    private fun processCheckout() {
        val total = CartManager.getTotalPrice()
        if (total > 0) {
            val intent = Intent(this, BookingActivity::class.java)
            intent.putExtra("event", "Order Payment of " + String.format("$%.2f", total))
            startActivity(intent)
            CartManager.clearCart()
            finish()
        } else {
            Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateEmptyState() {
        val layoutSummary = findViewById<View>(R.id.layoutSummary)
        if (CartManager.getCartItems().isEmpty()) {
            tvEmptyCart.visibility = View.VISIBLE
            rvCartItems.visibility = View.GONE
            layoutSummary.visibility = View.GONE
        } else {
            tvEmptyCart.visibility = View.GONE
            rvCartItems.visibility = View.VISIBLE
            layoutSummary.visibility = View.VISIBLE
        }
    }
}