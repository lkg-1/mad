package com.example.sample2mad

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample2mad.models.DataRepository

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rvMovies = findViewById<RecyclerView>(R.id.rvMovies)
        rvMovies.layoutManager = LinearLayoutManager(this)
        rvMovies.adapter = MovieAdapter(DataRepository.movies) { movie ->
            val intent = Intent(this, TheaterSelectionActivity::class.java)
            intent.putExtra("MOVIE", movie)
            startActivity(intent)
        }

        findViewById<Button>(R.id.btnViewTickets).setOnClickListener {
            startActivity(Intent(this, TicketsActivity::class.java))
        }
    }
}
