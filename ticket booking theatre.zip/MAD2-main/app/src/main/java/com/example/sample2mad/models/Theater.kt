package com.example.sample2mad.models

import java.io.Serializable

data class Movie(
    val id: String,
    val title: String,
    val genre: String
) : Serializable

data class Theater(
    val id: String,
    val name: String,
    val location: String
) : Serializable

data class Screen(
    val id: String,
    val name: String,
    val rows: Int,
    val cols: Int
) : Serializable

data class Show(
    val id: String,
    val movieId: String,
    val theaterId: String,
    val screenId: String,
    val date: String,
    val time: String,
    val bookedSeats: MutableList<String> = mutableListOf()
) : Serializable

data class Ticket(
    val id: String,
    val movieTitle: String,
    val theaterName: String,
    val date: String,
    val time: String,
    val seats: String
) : Serializable
