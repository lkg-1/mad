package com.example.sample2mad

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SeatAdapter(
    private val rows: Int,
    private val cols: Int,
    private val bookedSeats: List<String>,
    private val onSeatSelected: (String, Boolean) -> Unit
) : RecyclerView.Adapter<SeatAdapter.SeatViewHolder>() {

    private val selectedSeats = mutableSetOf<String>()

    class SeatViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvSeat: TextView = view.findViewById(R.id.tvSeat)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SeatViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_seat, parent, false)
        return SeatViewHolder(view)
    }

    override fun onBindViewHolder(holder: SeatViewHolder, position: Int) {
        val row = position / cols
        val col = position % cols
        val seatId = "${'A' + row}${col + 1}"

        holder.tvSeat.text = seatId

        when {
            bookedSeats.contains(seatId) -> {
                holder.tvSeat.setBackgroundResource(android.R.color.darker_gray)
                holder.tvSeat.setTextColor(Color.WHITE)
                holder.itemView.isEnabled = false
            }
            selectedSeats.contains(seatId) -> {
                holder.tvSeat.setBackgroundResource(R.drawable.bg_seat_selected)
                holder.tvSeat.setTextColor(Color.WHITE)
                holder.itemView.isEnabled = true
            }
            else -> {
                holder.tvSeat.setBackgroundResource(R.drawable.bg_seat_available)
                holder.tvSeat.setTextColor(Color.BLACK)
                holder.itemView.isEnabled = true
            }
        }

        holder.itemView.setOnClickListener {
            if (selectedSeats.contains(seatId)) {
                selectedSeats.remove(seatId)
                onSeatSelected(seatId, false)
            } else {
                selectedSeats.add(seatId)
                onSeatSelected(seatId, true)
            }
            notifyItemChanged(position)
        }
    }

    override fun getItemCount() = rows * cols
    
    fun getSelectedSeats() = selectedSeats.toList()
}
