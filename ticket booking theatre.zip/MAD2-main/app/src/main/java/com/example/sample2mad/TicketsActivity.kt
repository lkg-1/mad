package com.example.sample2mad

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample2mad.models.DataRepository
import com.example.sample2mad.models.Ticket

class TicketsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tickets)

        val rvTickets = findViewById<RecyclerView>(R.id.rvTickets)
        rvTickets.layoutManager = LinearLayoutManager(this)
        rvTickets.adapter = TicketAdapter(DataRepository.bookedTickets)
    }
}

class TicketAdapter(private val tickets: List<Ticket>) :
    RecyclerView.Adapter<TicketAdapter.TicketViewHolder>() {

    class TicketViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val movie: TextView = view.findViewById(R.id.tvTicketMovie)
        val theater: TextView = view.findViewById(R.id.tvTicketTheater)
        val dateTime: TextView = view.findViewById(R.id.tvTicketDateTime)
        val seats: TextView = view.findViewById(R.id.tvTicketSeats)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TicketViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_ticket, parent, false)
        return TicketViewHolder(view)
    }

    override fun onBindViewHolder(holder: TicketViewHolder, position: Int) {
        val ticket = tickets[position]
        holder.movie.text = ticket.movieTitle
        holder.theater.text = ticket.theaterName
        holder.dateTime.text = "${ticket.date} | ${ticket.time}"
        holder.seats.text = "Seats: ${ticket.seats}"
    }

    override fun getItemCount() = tickets.size
}
