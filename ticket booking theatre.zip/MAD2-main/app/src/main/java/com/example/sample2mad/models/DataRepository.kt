package com.example.sample2mad.models

object DataRepository {
    val movies = listOf(
        Movie("1", "Pushpa 2", "Action"),
        Movie("2", "Kanguva", "Action/Drama"),
        Movie("3", "Amaran", "Biography/Action")
    )

    val theaters = listOf(
        Theater("t1", "PVR Cinemas", "Velachery"),
        Theater("t2", "SPI Cinemas", "Royapettah"),
        Theater("t3", "AGS Cinemas", "T.Nagar")
    )

    val screens = listOf(
        Screen("s1", "Screen 1", 10, 10),
        Screen("s2", "Screen 2", 8, 8)
    )

    val shows = mutableListOf(
        Show("sh1", "1", "t1", "s1", "2024-05-20", "10:00 AM"),
        Show("sh2", "1", "t1", "s1", "2024-05-20", "02:00 PM"),
        Show("sh3", "2", "t2", "s2", "2024-05-20", "06:00 PM"),
        Show("sh4", "3", "t3", "s1", "2024-05-21", "10:30 PM")
    )

    val bookedTickets = mutableListOf<Ticket>()
}
