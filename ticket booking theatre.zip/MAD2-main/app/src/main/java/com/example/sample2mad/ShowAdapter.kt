package com.example.sample2mad

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.sample2mad.models.DataRepository
import com.example.sample2mad.models.Show

class ShowAdapter(private val shows: List<Show>, private val onClick: (Show) -> Unit) :
    RecyclerView.Adapter<ShowAdapter.ShowViewHolder>() {

    class ShowViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val theaterName: TextView = view.findViewById(R.id.tvTheaterName)
        val showTime: TextView = view.findViewById(R.id.tvShowTime)
        val theaterLocation: TextView = view.findViewById(R.id.tvTheaterLocation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShowViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_show, parent, false)
        return ShowViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShowViewHolder, position: Int) {
        val show = shows[position]
        val theater = DataRepository.theaters.find { it.id == show.theaterId }
        
        holder.theaterName.text = theater?.name ?: "Unknown Theater"
        holder.showTime.text = "${show.date} | ${show.time}"
        holder.theaterLocation.text = theater?.location ?: ""
        
        holder.itemView.setOnClickListener { onClick(show) }
    }

    override fun getItemCount() = shows.size
}
