package com.example.sample2mad

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample2mad.models.DataRepository
import com.example.sample2mad.models.Movie
import com.example.sample2mad.models.Show

class TheaterSelectionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_theater_selection)

        val movie = intent.getSerializableExtra("MOVIE") as Movie
        findViewById<TextView>(R.id.tvMovieTitleHeader).text = movie.title

        val rvShows = findViewById<RecyclerView>(R.id.rvShows)
        rvShows.layoutManager = LinearLayoutManager(this)
        
        val movieShows = DataRepository.shows.filter { it.movieId == movie.id }
        rvShows.adapter = ShowAdapter(movieShows) { show ->
            val intent = Intent(this, SeatSelectionActivity::class.java)
            intent.putExtra("SHOW", show)
            startActivity(intent)
        }
    }
}
