package com.example.sample2mad

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sample2mad.models.DataRepository
import com.example.sample2mad.models.Show
import com.example.sample2mad.models.Ticket

class SeatSelectionActivity : AppCompatActivity() {
    private lateinit var seatAdapter: SeatAdapter
    private var selectedSeatsCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seat_selection)

        val show = intent.getSerializableExtra("SHOW") as Show
        val movie = DataRepository.movies.find { it.id == show.movieId }
        val screen = DataRepository.screens.find { it.id == show.screenId }

        findViewById<TextView>(R.id.tvShowDetailsHeader).text = 
            "${movie?.title} - ${show.time} (${screen?.name})"

        val rvSeats = findViewById<RecyclerView>(R.id.rvSeats)
        if (screen != null) {
            rvSeats.layoutManager = GridLayoutManager(this, screen.cols)
            seatAdapter = SeatAdapter(screen.rows, screen.cols, show.bookedSeats) { seatId, isSelected ->
                if (isSelected) selectedSeatsCount++ else selectedSeatsCount--
            }
            rvSeats.adapter = seatAdapter
        }

        findViewById<Button>(R.id.btnBookTickets).setOnClickListener {
            val selected = seatAdapter.getSelectedSeats()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Please select at least one seat", Toast.LENGTH_SHORT).show()
            } else {
                show.bookedSeats.addAll(selected)
                
                val ticket = Ticket(
                    id = System.currentTimeMillis().toString(),
                    movieTitle = movie?.title ?: "Unknown",
                    theaterName = DataRepository.theaters.find { it.id == show.theaterId }?.name ?: "Unknown",
                    date = show.date,
                    time = show.time,
                    seats = selected.joinToString(", ")
                )
                DataRepository.bookedTickets.add(ticket)

                Toast.makeText(this, "Successfully booked: ${selected.joinToString(", ")}", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }
}
