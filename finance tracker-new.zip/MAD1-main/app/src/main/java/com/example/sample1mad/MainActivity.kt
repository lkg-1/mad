package com.example.sample1mad

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var etName: EditText
    private lateinit var etAmount: EditText
    private lateinit var tvTotalInflow: TextView
    private lateinit var tvTotalOutflow: TextView
    private lateinit var tvBalance: TextView

    private val CHANNEL_ID = "finance_notifications"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        dbHelper = DatabaseHelper(this)
        createNotificationChannel()
        requestNotificationPermission()

        etName = findViewById(R.id.etName)
        etAmount = findViewById(R.id.etAmount)
        tvTotalInflow = findViewById(R.id.tvTotalInflow)
        tvTotalOutflow = findViewById(R.id.tvTotalOutflow)
        tvBalance = findViewById(R.id.tvBalance)

        val btnAddIncome: Button = findViewById(R.id.btnAddIncome)
        val btnAddExpense: Button = findViewById(R.id.btnAddExpense)
        val btnReset: Button = findViewById(R.id.btnReset)

        btnAddIncome.setOnClickListener {
            addTransaction("credit")
        }

        btnAddExpense.setOnClickListener {
            addTransaction("debit")
        }

        btnReset.setOnClickListener {
            dbHelper.resetData()
            updateUI()
            Toast.makeText(this, "Data Reset", Toast.LENGTH_SHORT).show()
        }

        updateUI()
    }

    private fun addTransaction(type: String) {
        val name = etName.text.toString()
        val amountStr = etAmount.text.toString()

        if (name.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter name and amount", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull() ?: 0.0
        dbHelper.addTransaction(type, name, amount)

        etName.text.clear()
        etAmount.text.clear()

        updateUI()
        checkBudget()
    }

    private fun updateUI() {
        val inflow = dbHelper.getTotalInflow()
        val outflow = dbHelper.getTotalOutflow()
        val balance = inflow - outflow

        tvTotalInflow.text = "Total Inflow: $%.2f".format(inflow)
        tvTotalOutflow.text = "Total Outflow: $%.2f".format(outflow)
        tvBalance.text = "Balance: $%.2f".format(balance)
    }

    private fun checkBudget() {
        val inflow = dbHelper.getTotalInflow()
        val outflow = dbHelper.getTotalOutflow()

        if (outflow > inflow) {
            sendNotification("Budget Alert", "Your total spent ($outflow) exceeds your inflow ($inflow)!")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Finance Alerts"
            val descriptionText = "Notifications for budget exceeding inflow"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    private fun sendNotification(title: String, message: String) {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        val notificationManager: NotificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, builder.build())
    }
}
